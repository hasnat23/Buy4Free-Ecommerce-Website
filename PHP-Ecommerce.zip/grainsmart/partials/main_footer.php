</div>
<footer class="main-footer">
	<p style="letter-spacing: 2px;">Copyright &copy; 2018 by LGV Enterprise. Web design by <a href="https://jrotoni.github.io" target="_blank">jrotoni.</a></p>
</footer>
