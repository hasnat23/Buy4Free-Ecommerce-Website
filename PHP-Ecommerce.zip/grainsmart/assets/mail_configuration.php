<?php
define("PROJECT_HOME","http://localhost/grainsmart/");

define("PORT", "587");
define("MAIL_USERNAME", "grainsmart.cainta@gmail.com");
define("MAIL_PASSWORD", "Grainsmart************");
define("MAIL_HOST", "smtp.gmail.com");
define("MAILER", "smtp");

define("SENDER_NAME", "Grainsmart Cainta");
define("SERDER_EMAIL", "grainsmart.cainta@gmail.com");
?>